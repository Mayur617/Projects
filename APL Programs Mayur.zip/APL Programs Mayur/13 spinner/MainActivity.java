package com.example.apl_2; // Replace with your actual package name

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Declare UI elements
    private Spinner spinnerOptions;
    private TextView textViewSelectedOption;

    // Data source for the Spinner
    private String[] options = {
            "Option 1", "Option 2", "Option 3", "Option 4", "Option 5"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content view to the activity_main.xml layout
        setContentView(R.layout.activity_main);

        // Initialize UI elements by finding them by their IDs from the layout
        spinnerOptions = findViewById(R.id.spinnerOptions);
        textViewSelectedOption = findViewById(R.id.textViewSelectedOption);

        // Create an ArrayAdapter to bind the data source to the Spinner
        // android.R.layout.simple_spinner_item is a built-in layout for spinner items
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                options
        );

        // Specify the layout to use when the list of choices appears
        // android.R.layout.simple_spinner_dropdown_item is a built-in layout for dropdown items
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // Apply the adapter to the spinner
        spinnerOptions.setAdapter(adapter);

        // Set an OnItemSelectedListener to handle item selection events
        spinnerOptions.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // This method is called when an item is selected in the Spinner

                // Get the selected item's text
                String selectedOption = parent.getItemAtPosition(position).toString();

                // Update the TextView to display the selected option
                textViewSelectedOption.setText("Selected Option: " + selectedOption);

                // Optionally, show a Toast message
                Toast.makeText(MainActivity.this, "Selected: " + selectedOption, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // This method is called when no item is selected (e.g., when the selection is cleared)
                // In this example, we don't need to do anything specific here.
            }
        });
    }
}
