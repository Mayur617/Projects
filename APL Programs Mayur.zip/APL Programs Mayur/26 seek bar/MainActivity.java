package com.example.apl_2; // Replace with your actual package name

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.SeekBar; // Import SeekBar
import android.widget.TextView; // Import TextView
import android.widget.Toast;  // Import Toast

public class MainActivity extends AppCompatActivity {

    // Declare UI elements
    private SeekBar seekBar;
    private TextView textViewProgressValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content view to the activity_main.xml layout
        setContentView(R.layout.activity_main);

        // Initialize UI elements by finding them by their IDs from the layout
        seekBar = findViewById(R.id.seekBar);
        textViewProgressValue = findViewById(R.id.textViewProgressValue);

        // Set the initial text based on the default progress
        textViewProgressValue.setText("Progress: " + seekBar.getProgress());

        // Set an OnSeekBarChangeListener to handle progress changes
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // This method is called when the progress level has changed.
                // 'progress' is the current progress value.
                // 'fromUser' is true if the progress change was initiated by the user.

                // Update the TextView to display the new progress value
                textViewProgressValue.setText("Progress: " + progress);

                // Optionally, show a Toast message when the user is actively dragging
                if (fromUser) {
                    // You could add a Toast here for real-time feedback while dragging,
                    // but it might be too frequent.
                    // Toast.makeText(MainActivity.this, "Dragging: " + progress, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // This method is called when the user starts touching the seek bar.
                Toast.makeText(MainActivity.this, "Started Tracking", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // This method is called when the user stops touching the seek bar.
                Toast.makeText(MainActivity.this, "Stopped Tracking at: " + seekBar.getProgress(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
