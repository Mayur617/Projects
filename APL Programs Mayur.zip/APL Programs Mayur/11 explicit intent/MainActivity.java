package com.example.apl_2; // Replace with your actual package name

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    // Declare the button
    private Button buttonLaunchSecondActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content view to the activity_main.xml layout
        setContentView(R.layout.activity_main);

        // Initialize the button by finding it by its ID
        buttonLaunchSecondActivity = findViewById(R.id.buttonLaunchSecondActivity);

        // Set an OnClickListener for the button
        buttonLaunchSecondActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an explicit intent to start SecondActivity
                // The constructor takes the current context and the class of the target activity
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);

                // Start the activity specified by the intent
                startActivity(intent);
            }
        });
    }
}
