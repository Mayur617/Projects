package com.example.apl_2; // Replace with your actual package name

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content view to the activity_second.xml layout
        setContentView(R.layout.activity_second);

        // No additional logic needed for this simple example
    }
}
