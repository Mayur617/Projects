package com.example.apl_2; // Replace with your actual package name

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Declare UI elements
    private EditText editTextInput;
    private Button buttonAction;
    private TextView textViewOutput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content view to the activity_main.xml layout
        setContentView(R.layout.activity_main);

        // Initialize UI elements by finding them by their IDs from the layout
        editTextInput = findViewById(R.id.editTextInput);
        buttonAction = findViewById(R.id.buttonAction);
        textViewOutput = findViewById(R.id.textViewOutput);

        // Set an OnClickListener for the button
        buttonAction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get text from the EditText field
                String inputText = editTextInput.getText().toString();

                // Check if the input is not empty
                if (!inputText.isEmpty()) {
                    // Update the output TextView with the input text
                    textViewOutput.setText("You entered: " + inputText);
                    // Show a brief message (Toast)
                    Toast.makeText(MainActivity.this, "Text Processed!", Toast.LENGTH_SHORT).show();
                } else {
                    // If the input is empty, show a message
                    textViewOutput.setText("Please enter some text.");
                    Toast.makeText(MainActivity.this, "Input is empty!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
