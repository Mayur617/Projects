package com.example.apl_2; // Replace with your actual package name

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast; // Import Toast

public class MainActivity extends AppCompatActivity {

    // Declare UI elements
    private TextView textViewProgress;
    private Button buttonStartTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content view to the activity_main.xml layout
        setContentView(R.layout.activity_main);

        // Initialize UI elements by finding them by their IDs from the layout
        textViewProgress = findViewById(R.id.textViewProgress);
        buttonStartTask = findViewById(R.id.buttonStartTask);

        // Set an OnClickListener for the button
        buttonStartTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // --- Event Handler Logic for Button Click ---

                // Disable the button to prevent starting multiple tasks
                buttonStartTask.setEnabled(false);
                textViewProgress.setText("Progress: Starting...");

                // Create and start a new Thread for the background task
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        // --- Code that runs in the background thread ---

                        for (int i = 0; i <= 10; i++) {
                            final int progress = i; // Make progress final to use in inner Runnable

                            // Simulate some work
                            try {
                                Thread.sleep(1000); // Pause for 1 second
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                                // If the thread is interrupted, break the loop
                                break;
                            }

                            // Update the UI (TextView) from the background thread
                            // You cannot directly update UI elements from a background thread.
                            // Use runOnUiThread() to post an action to the main UI thread.
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    // --- Code that runs on the main UI thread ---
                                    textViewProgress.setText("Progress: " + progress);
                                }
                            });
                        }

                        // Task is complete, update UI on the main thread
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MainActivity.this, "Task Complete!", Toast.LENGTH_SHORT).show();
                                // Re-enable the button
                                buttonStartTask.setEnabled(true);
                            }
                        });
                    }
                }).start(); // Start the new thread
            }
        });
    }
}
