package com.example.apl_2; // Replace with your actual package name

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Declare the ListView
    private ListView listViewItems;

    // Data source for the ListView
    private String[] items = {
            "Item 1", "Item 2", "Item 3", "Item 4", "Item 5",
            "Item 6", "Item 7", "Item 8", "Item 9", "Item 10",
            "Item 11", "Item 12", "Item 13", "Item 14", "Item 15"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content view to the activity_main.xml layout
        setContentView(R.layout.activity_main);

        // Initialize the ListView by finding it by its ID from the layout
        listViewItems = findViewById(R.id.listViewItems);

        // Create an ArrayAdapter to bind the data source to the ListView
        // android.R.layout.simple_list_item_1 is a built-in layout for a single TextView
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                items
        );

        // Set the adapter on the ListView
        listViewItems.setAdapter(adapter);

        // Set an OnItemClickListener to handle clicks on list items
        listViewItems.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Get the clicked item text
                String selectedItem = (String) parent.getItemAtPosition(position);

                // Display a Toast message with the selected item
                Toast.makeText(MainActivity.this, "Clicked: " + selectedItem, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
