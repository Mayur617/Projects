package com.example.apl_2; // Replace with your actual package name

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Declare UI elements
    private Button buttonOpenWeb;
    private Button buttonDialNumber;
    private Button buttonViewMap;
    private Button buttonSendEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content view to the activity_main.xml layout
        setContentView(R.layout.activity_main);

        // Initialize UI elements by finding them by their IDs from the layout
        buttonOpenWeb = findViewById(R.id.buttonOpenWeb);
        buttonDialNumber = findViewById(R.id.buttonDialNumber);
        buttonViewMap = findViewById(R.id.buttonViewMap);
        buttonSendEmail = findViewById(R.id.buttonSendEmail);

        // Set OnClickListener for the "Open Web Page" button
        buttonOpenWeb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Define the URI for the web page
                Uri webpage = Uri.parse("https://www.google.com");
                // Create an implicit intent with the ACTION_VIEW action and the URI
                Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);
                // Check if there is an app available to handle this intent
                if (webIntent.resolveActivity(getPackageManager()) != null) {
                    // Start the activity
                    startActivity(webIntent);
                } else {
                    // Show a message if no app can handle the intent
                    Toast.makeText(MainActivity.this, "No app found to open web page.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Set OnClickListener for the "Dial Number" button
        buttonDialNumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Define the URI for the phone number (using "tel:" scheme)
                Uri number = Uri.parse("tel:1234567890"); // Replace with a valid number
                // Create an implicit intent with the ACTION_DIAL action and the URI
                Intent dialIntent = new Intent(Intent.ACTION_DIAL, number);
                // Check if there is an app available to handle this intent
                if (dialIntent.resolveActivity(getPackageManager()) != null) {
                    // Start the activity
                    startActivity(dialIntent);
                } else {
                    // Show a message if no app can handle the intent
                    Toast.makeText(MainActivity.this, "No app found to dial number.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Set OnClickListener for the "View Map" button
        buttonViewMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Define the URI for the map location (using "geo:" scheme)
                // Format: geo:latitude,longitude?z=zoom
                Uri location = Uri.parse("geo:19.0760,72.8777?z=10"); // Example: Mumbai coordinates
                // Create an implicit intent with the ACTION_VIEW action and the URI
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, location);
                // Check if there is an app available to handle this intent
                if (mapIntent.resolveActivity(getPackageManager()) != null) {
                    // Start the activity
                    startActivity(mapIntent);
                } else {
                    // Show a message if no app can handle the intent
                    Toast.makeText(MainActivity.this, "No app found to view map.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Set OnClickListener for the "Send Email" button
        buttonSendEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an implicit intent with the ACTION_SENDTO action (for sending data to a specific recipient)
                Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
                // Set the data URI with the "mailto:" scheme and recipient email address
                emailIntent.setData(Uri.parse("mailto:recipient@example.com")); // Replace with recipient email
                // Add subject and body as extras (optional)
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Subject Here");
                emailIntent.putExtra(Intent.EXTRA_TEXT, "Email body here.");

                // Check if there is an app available to handle this intent
                if (emailIntent.resolveActivity(getPackageManager()) != null) {
                    // Start the activity
                    startActivity(emailIntent);
                } else {
                    // Show a message if no app can handle the intent
                    Toast.makeText(MainActivity.this, "No app found to send email.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
