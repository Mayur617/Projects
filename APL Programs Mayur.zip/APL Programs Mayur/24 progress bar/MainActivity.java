package com.example.apl_2; // Replace with your actual package name

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast; // Import Toast

public class MainActivity extends AppCompatActivity {

    // Declare UI elements
    private TextView textViewPercentage;
    private ProgressBar progressBar;
    private Button buttonStartProgress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content view to the activity_main.xml layout
        setContentView(R.layout.activity_main);

        // Initialize UI elements by finding them by their IDs from the layout
        textViewPercentage = findViewById(R.id.textViewPercentage);
        progressBar = findViewById(R.id.progressBar);
        buttonStartProgress = findViewById(R.id.buttonStartProgress);

        // Set the initial progress and text
        progressBar.setProgress(0);
        textViewPercentage.setText("0%");

        // Set an OnClickListener for the button
        buttonStartProgress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // --- Event Handler Logic for Button Click ---

                // Disable the button to prevent starting multiple tasks
                buttonStartProgress.setEnabled(false);
                textViewPercentage.setText("Starting...");
                progressBar.setProgress(0); // Reset progress

                // Create and start a new Thread for the background task
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        // --- Code that runs in the background thread ---

                        // Simulate a task with 100 steps
                        for (int i = 0; i <= 100; i++) {
                            final int currentProgress = i; // Make progress final to use in inner Runnable

                            // Simulate some work
                            try {
                                Thread.sleep(50); // Pause briefly (adjust for faster/slower progress)
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                                // If the thread is interrupted, break the loop
                                break;
                            }

                            // Update the UI (ProgressBar and TextView) from the background thread
                            // You cannot directly update UI elements from a background thread.
                            // Use runOnUiThread() to post an action to the main UI thread.
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    // --- Code that runs on the main UI thread ---
                                    progressBar.setProgress(currentProgress);
                                    textViewPercentage.setText(currentProgress + "%");
                                }
                            });
                        }

                        // Task is complete, update UI on the main thread
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MainActivity.this, "Progress Complete!", Toast.LENGTH_SHORT).show();
                                // Re-enable the button
                                buttonStartProgress.setEnabled(true);
                            }
                        });
                    }
                }).start(); // Start the new thread
            }
        });
    }
}
