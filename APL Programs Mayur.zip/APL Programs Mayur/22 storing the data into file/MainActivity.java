package com.example.apl_2; // Replace with your actual package name

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context; // Import Context
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast; // Import Toast

import java.io.FileOutputStream; // Import FileOutputStream
import java.io.IOException; // Import IOException

public class MainActivity extends AppCompatActivity {

    // Declare UI elements
    private EditText editTextInput;
    private Button buttonSaveFile;

    // Define the name of the file
    private static final String FILE_NAME = "my_saved_text.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content view to the activity_main.xml layout
        setContentView(R.layout.activity_main);

        // Initialize UI elements by finding them by their IDs from the layout
        editTextInput = findViewById(R.id.editTextInput);
        buttonSaveFile = findViewById(R.id.buttonSaveFile);

        // Set an OnClickListener for the Save File button
        buttonSaveFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // --- Event Handler Logic for Button Click ---

                // Get text from the EditText field
                String textToSave = editTextInput.getText().toString();

                // Check if the text is not empty
                if (textToSave.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter some text to save.", Toast.LENGTH_SHORT).show();
                    return; // Exit if text is empty
                }

                FileOutputStream fos = null; // Declare FileOutputStream outside try block

                try {
                    // Open a FileOutputStream for writing to the file in internal storage
                    // MODE_PRIVATE ensures that the file can only be accessed by this app
                    fos = openFileOutput(FILE_NAME, Context.MODE_PRIVATE);

                    // Write the text to the file
                    fos.write(textToSave.getBytes());

                    // Show a success message
                    Toast.makeText(MainActivity.this, "Text saved to " + getFilesDir() + "/" + FILE_NAME, Toast.LENGTH_LONG).show();

                    // Clear the input field after saving
                    editTextInput.setText("");

                } catch (IOException e) {
                    // Handle potential IO errors
                    e.printStackTrace(); // Print the stack trace for debugging
                    Toast.makeText(MainActivity.this, "Error saving file: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                } finally {
                    // Ensure the FileOutputStream is closed in the finally block
                    if (fos != null) {
                        try {
                            fos.close();
                        } catch (IOException e) {
                            e.printStackTrace(); // Log the exception during closing
                        }
                    }
                }
            }
        });
    }
}
