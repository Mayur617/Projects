package com.example.apl_2; // Replace with your actual package name

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    // Declare UI elements
    private EditText editTextName;
    private EditText editTextEmail;
    private EditText editTextPassword;
    private RadioGroup radioGroupGender;
    private CheckBox checkBoxTerms;
    private ToggleButton toggleButtonSubscribe;
    private Button buttonRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content view to the activity_main.xml layout
        setContentView(R.layout.activity_main);

        // Initialize UI elements by finding them by their IDs from the layout
        editTextName = findViewById(R.id.editTextName);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);
        radioGroupGender = findViewById(R.id.radioGroupGender);
        checkBoxTerms = findViewById(R.id.checkBoxTerms);
        toggleButtonSubscribe = findViewById(R.id.toggleButtonSubscribe);
        buttonRegister = findViewById(R.id.buttonRegister);

        // Set an OnClickListener for the Register button
        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // --- Event Handler Logic for Button Click ---

                // Get data from Text Fields
                String name = editTextName.getText().toString().trim(); // trim() removes leading/trailing whitespace
                String email = editTextEmail.getText().toString().trim();
                String password = editTextPassword.getText().toString().trim();

                // Get selected Gender from Radio Buttons
                int selectedGenderId = radioGroupGender.getCheckedRadioButtonId();
                String gender = "";
                if (selectedGenderId != -1) { // Check if a radio button is selected
                    RadioButton selectedRadioButton = findViewById(selectedGenderId);
                    gender = selectedRadioButton.getText().toString();
                } else {
                    gender = "Not specified";
                }

                // Get state of Checkbox
                boolean termsAgreed = checkBoxTerms.isChecked();

                // Get state of Toggle Button
                boolean isSubscribed = toggleButtonSubscribe.isChecked();

                // --- Perform basic validation and display collected data ---

                if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please fill in all fields.", Toast.LENGTH_SHORT).show();
                } else if (!termsAgreed) {
                    Toast.makeText(MainActivity.this, "Please agree to the terms and conditions.", Toast.LENGTH_SHORT).show();
                }
                else {
                    // Display collected information (e.g., in a Toast)
                    String registrationSummary = "Registration Details:\n" +
                            "Name: " + name + "\n" +
                            "Email: " + email + "\n" +
                            "Password: " + password + " (for demo, don't show in real app!)\n" +
                            "Gender: " + gender + "\n" +
                            "Terms Agreed: " + termsAgreed + "\n" +
                            "Subscribed: " + isSubscribed;

                    Toast.makeText(MainActivity.this, registrationSummary, Toast.LENGTH_LONG).show();

                    // In a real application, you would send this data to a server or database here.
                }
            }
        });

        // --- Optional: Add event handlers for other elements to show immediate feedback ---

        // Example: OnCheckedChangeListener for CheckBox
        checkBoxTerms.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // This lambda syntax is a shorthand for OnCheckedChangeListener
            if (isChecked) {
                Toast.makeText(MainActivity.this, "Terms Agreed!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "Terms Disagreed!", Toast.LENGTH_SHORT).show();
            }
        });

        // Example: OnCheckedChangeListener for ToggleButton
        toggleButtonSubscribe.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                Toast.makeText(MainActivity.this, "Subscribed!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "Unsubscribed!", Toast.LENGTH_SHORT).show();
            }
        });

        // Note: RadioGroup has its own OnCheckedChangeListener to detect which RadioButton is selected
        radioGroupGender.setOnCheckedChangeListener((group, checkedId) -> {
            RadioButton checkedRadioButton = findViewById(checkedId);
            if (checkedRadioButton != null) {
                Toast.makeText(MainActivity.this, "Gender selected: " + checkedRadioButton.getText(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
