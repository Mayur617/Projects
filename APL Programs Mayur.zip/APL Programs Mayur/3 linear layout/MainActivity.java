package com.example.apl_2; // Replace with your actual package name

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Declare UI elements
    private EditText editTextName;
    private Button buttonSubmit;
    private TextView textViewOutput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content view to the activity_main.xml layout
        setContentView(R.layout.activity_main);

        // Initialize UI elements by finding them by their IDs from the layout
        editTextName = findViewById(R.id.editTextName);
        buttonSubmit = findViewById(R.id.buttonSubmit);
        textViewOutput = findViewById(R.id.textViewOutput);

        // Set an OnClickListener for the submit button
        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the text from the EditText
                String name = editTextName.getText().toString();

                // Check if the name is not empty
                if (!name.isEmpty()) {
                    // Update the output TextView with the entered name
                    textViewOutput.setText("Hello, " + name + "!");
                    // Show a brief message (Toast)
                    Toast.makeText(MainActivity.this, "Submitted!", Toast.LENGTH_SHORT).show();
                } else {
                    // If the name is empty, show an error message
                    textViewOutput.setText("Please enter your name.");
                    Toast.makeText(MainActivity.this, "Name is empty!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
