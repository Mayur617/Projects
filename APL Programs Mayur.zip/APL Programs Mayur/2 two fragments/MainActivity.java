package com.example.apl_2; // Replace with your package name

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Get the FragmentManager
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        // Add FragmentOne to fragment_container_one
        FragmentOne fragmentOne = new FragmentOne();
        fragmentTransaction.add(R.id.fragment_container_one, fragmentOne);

        // Add FragmentTwo to fragment_container_two
        FragmentTwo fragmentTwo = new FragmentTwo();
        fragmentTransaction.add(R.id.fragment_container_two, fragmentTwo);

        // Commit the transaction
        fragmentTransaction.commit();
    }
}