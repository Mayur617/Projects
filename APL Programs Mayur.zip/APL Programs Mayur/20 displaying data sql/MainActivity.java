package com.example.apl_2; // Replace with your actual package name

import androidx.appcompat.app.AppCompatActivity;
import androidx.cursoradapter.widget.SimpleCursorAdapter; // Import SimpleCursorAdapter
import android.content.ContentValues; // Import ContentValues
import android.database.Cursor; // Import Cursor
import android.database.sqlite.SQLiteDatabase; // Import SQLiteDatabase
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast; // Import Toast

public class MainActivity extends AppCompatActivity {

    // Declare UI elements
    private EditText editTextName;
    private EditText editTextAge;
    private Button buttonAddData;
    private Button buttonShowData;
    private ListView listViewData;

    // Declare DatabaseHelper instance
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content view to the activity_main.xml layout
        setContentView(R.layout.activity_main);

        // Initialize UI elements by finding them by their IDs from the layout
        editTextName = findViewById(R.id.editTextName);
        editTextAge = findViewById(R.id.editTextAge);
        buttonAddData = findViewById(R.id.buttonAddData);
        buttonShowData = findViewById(R.id.buttonShowData);
        listViewData = findViewById(R.id.listViewData);

        // Initialize the DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        // Set an OnClickListener for the Add Data button
        buttonAddData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // --- Event Handler Logic for Add Data Button Click ---

                // Get data from EditText fields
                String name = editTextName.getText().toString().trim();
                String ageString = editTextAge.getText().toString().trim();

                // Basic validation
                if (name.isEmpty() || ageString.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter both name and age.", Toast.LENGTH_SHORT).show();
                    return; // Exit if fields are empty
                }

                int age;
                try {
                    age = Integer.parseInt(ageString);
                } catch (NumberFormatException e) {
                    Toast.makeText(MainActivity.this, "Please enter a valid age.", Toast.LENGTH_SHORT).show();
                    return; // Exit if age is not a valid number
                }

                // Get a writable database instance
                SQLiteDatabase db = dbHelper.getWritableDatabase();

                // Create a new map of values, where column names are the keys
                ContentValues values = new ContentValues();
                values.put(DatabaseHelper.COLUMN_NAME, name);
                values.put(DatabaseHelper.COLUMN_AGE, age);

                // Insert the new row, returning the primary key value of the new row
                long newRowId = db.insert(DatabaseHelper.TABLE_NAME, null, values);

                // Check if insertion was successful
                if (newRowId != -1) {
                    Toast.makeText(MainActivity.this, "Data inserted with ID: " + newRowId, Toast.LENGTH_SHORT).show();
                    // Clear the input fields after successful insertion
                    editTextName.setText("");
                    editTextAge.setText("");
                } else {
                    Toast.makeText(MainActivity.this, "Error inserting data.", Toast.LENGTH_SHORT).show();
                }

                // Close the database connection
                db.close();
            }
        });

        // Set an OnClickListener for the Show Data button
        buttonShowData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // --- Event Handler Logic for Show Data Button Click ---
                displayData(); // Call the method to display data
            }
        });
    }

    // Method to retrieve and display data from the database in the ListView
    private void displayData() {
        // Get a readable database instance
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Define a projection that specifies which columns from the database you will actually use after this query.
        String[] projection = {
                DatabaseHelper.COLUMN_ID,
                DatabaseHelper.COLUMN_NAME,
                DatabaseHelper.COLUMN_AGE
        };

        // How you want the results sorted in the resulting Cursor
        String sortOrder = DatabaseHelper.COLUMN_NAME + " ASC"; // Sort by name ascending

        // Query the database
        Cursor cursor = db.query(
                DatabaseHelper.TABLE_NAME,   // The table to query
                projection,                  // The columns to return
                null,                        // The columns for the WHERE clause
                null,                        // The values for the WHERE clause
                null,                        // Don't group the rows
                null,                        // Don't filter by row groups
                sortOrder                    // The sort order
        );

        // Check if the cursor is null or empty
        if (cursor == null || cursor.getCount() == 0) {
            Toast.makeText(this, "No data found in the database.", Toast.LENGTH_SHORT).show();
            // Close the cursor and database connection
            if (cursor != null) {
                cursor.close();
            }
            db.close();
            // Optionally clear the ListView if no data is found
            listViewData.setAdapter(null);
            return;
        }

        // Define the columns from the database to map to views
        // We'll combine Name and Age into a single string for display in a single TextView
        String[] fromColumns = {
                DatabaseHelper.COLUMN_NAME,
                DatabaseHelper.COLUMN_AGE
        };

        // Define the TextViews in the list item layout to display the data
        int[] toViews = {
                android.R.id.text1 // This is the ID of the TextView in android.R.layout.simple_list_item_1
        };

        // Create a SimpleCursorAdapter
        // The adapter maps columns from the Cursor to views in the list item layout.
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(
                this,                               // Context
                android.R.layout.simple_list_item_1, // Layout for list items (a single TextView)
                cursor,                             // Cursor containing the data
                fromColumns,                        // Array of column names to bind to
                toViews,                            // Array of views to bind data to
                0                                   // Flags (0 for no flags)
        );

        // To display both name and age in a single TextView using SimpleCursorAdapter,
        // we need to customize how the data is bound. We can use a ViewBinder.
        adapter.setViewBinder(new SimpleCursorAdapter.ViewBinder() {
            @Override
            public boolean setViewValue(View view, Cursor cursor, int columnIndex) {
                if (columnIndex == cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_NAME)) {
                    // Get name and age from the cursor
                    String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_NAME));
                    int age = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_AGE));

                    // Set the text of the TextView to combine name and age
                    TextView textView = (TextView) view;
                    textView.setText("Name: " + name + ", Age: " + age);

                    // Indicate that the data was bound
                    return true;
                }
                // Let SimpleCursorAdapter handle other columns (though we only have one TextView)
                return false;
            }
        });


        // Set the adapter on the ListView
        listViewData.setAdapter(adapter);

        // Close the database connection (the cursor will be managed by the adapter)
        // Note: The Cursor is managed by the SimpleCursorAdapter, so we don't close it here.
        // The adapter will handle closing the cursor when it's no longer needed.
        db.close();
    }

    // Close the database helper when the activity is destroyed
    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}
