package com.example.apl_2;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class NewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content view to the layout defined in activity_new.xml
        setContentView(R.layout.activity_new);
    }
}
