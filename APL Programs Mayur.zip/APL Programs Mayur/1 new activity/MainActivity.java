package com.example.apl_2; // Replace with your actual package name

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button openNewActivityButton; // Declare the button object

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content view to the layout defined in activity_main.xml
        setContentView(R.layout.activity_main);

        // Find the button in the layout using its ID
        openNewActivityButton = findViewById(R.id.openNewActivityButton);

        // Set an OnClickListener to the button
        // This listener will be triggered when the button is clicked
        openNewActivityButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an Intent to specify the target Activity
                // The first argument is the context (usually the current Activity)
                // The second argument is the class of the Activity to start
                Intent intent = new Intent(MainActivity.this, NewActivity.class);

                // Start the new Activity using the Intent
                startActivity(intent);
            }
        });
    }
}
