package com.example.apl_2; // Replace with your actual package name

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues; // Import ContentValues
import android.database.sqlite.SQLiteDatabase; // Import SQLiteDatabase
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast; // Import Toast

public class MainActivity extends AppCompatActivity {

    // Declare UI elements
    private EditText editTextName;
    private EditText editTextAge;
    private Button buttonAddData;

    // Declare DatabaseHelper instance
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content view to the activity_main.xml layout
        setContentView(R.layout.activity_main);

        // Initialize UI elements by finding them by their IDs from the layout
        editTextName = findViewById(R.id.editTextName);
        editTextAge = findViewById(R.id.editTextAge);
        buttonAddData = findViewById(R.id.buttonAddData);

        // Initialize the DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        // Set an OnClickListener for the Add Data button
        buttonAddData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // --- Event Handler Logic for Button Click ---

                // Get data from EditText fields
                String name = editTextName.getText().toString().trim();
                String ageString = editTextAge.getText().toString().trim();

                // Basic validation
                if (name.isEmpty() || ageString.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter both name and age.", Toast.LENGTH_SHORT).show();
                    return; // Exit if fields are empty
                }

                int age;
                try {
                    age = Integer.parseInt(ageString);
                } catch (NumberFormatException e) {
                    Toast.makeText(MainActivity.this, "Please enter a valid age.", Toast.LENGTH_SHORT).show();
                    return; // Exit if age is not a valid number
                }

                // Get a writable database instance
                SQLiteDatabase db = dbHelper.getWritableDatabase();

                // Create a new map of values, where column names are the keys
                ContentValues values = new ContentValues();
                values.put(DatabaseHelper.COLUMN_NAME, name);
                values.put(DatabaseHelper.COLUMN_AGE, age);

                // Insert the new row, returning the primary key value of the new row
                // The first argument is the table name.
                // The second argument is a column name in which the framework can insert NULL in the event
                // that the ContentValues is empty.
                // The third argument is the ContentValues object containing the column-value pairs.
                long newRowId = db.insert(DatabaseHelper.TABLE_NAME, null, values);

                // Check if insertion was successful
                if (newRowId != -1) {
                    Toast.makeText(MainActivity.this, "Data inserted with ID: " + newRowId, Toast.LENGTH_SHORT).show();
                    // Clear the input fields after successful insertion
                    editTextName.setText("");
                    editTextAge.setText("");
                } else {
                    Toast.makeText(MainActivity.this, "Error inserting data.", Toast.LENGTH_SHORT).show();
                }

                // Close the database connection
                db.close();
            }
        });
    }

    // Close the database helper when the activity is destroyed
    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}
