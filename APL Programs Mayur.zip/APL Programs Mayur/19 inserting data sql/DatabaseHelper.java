package com.example.apl_2; // Replace with your actual package name

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database name and version
    private static final String DATABASE_NAME = "mydatabase.db";
    private static final int DATABASE_VERSION = 1;

    // Table name and column names
    public static final String TABLE_NAME = "users";
    public static final String COLUMN_ID = "_id"; // Recommended to use _id for ListView compatibility
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_AGE = "age";

    // SQL statement to create the users table
    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + // Auto-incrementing primary key
                    COLUMN_NAME + " TEXT," +
                    COLUMN_AGE + " INTEGER)";

    // SQL statement to drop the users table if it exists
    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + TABLE_NAME;

    // Constructor
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Called when the database is created for the first time
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Execute the SQL statement to create the table
        db.execSQL(SQL_CREATE_ENTRIES);
    }

    // Called when the database needs to be upgraded
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // This database is only a cache for online data, so its upgrade policy is
        // to simply to discard the data and start over.
        db.execSQL(SQL_DELETE_ENTRIES); // Drop the old table
        onCreate(db); // Create a new one
    }

    // Called when the database needs to be downgraded
    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion); // Simply call onUpgrade
    }
}
