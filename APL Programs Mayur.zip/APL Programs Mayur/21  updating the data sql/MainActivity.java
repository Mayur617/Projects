package com.example.apl_2; // Replace with your actual package name

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues; // Import ContentValues
import android.database.sqlite.SQLiteDatabase; // Import SQLiteDatabase
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast; // Import Toast

public class MainActivity extends AppCompatActivity {

    // Declare UI elements
    private EditText editTextIdToUpdate;
    private EditText editTextNewName;
    private EditText editTextNewAge;
    private Button buttonUpdateData;

    // Declare DatabaseHelper instance
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content view to the activity_main.xml layout
        setContentView(R.layout.activity_main);

        // Initialize UI elements by finding them by their IDs from the layout
        editTextIdToUpdate = findViewById(R.id.editTextIdToUpdate);
        editTextNewName = findViewById(R.id.editTextNewName);
        editTextNewAge = findViewById(R.id.editTextNewAge);
        buttonUpdateData = findViewById(R.id.buttonUpdateData);

        // Initialize the DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        // Set an OnClickListener for the Update Data button
        buttonUpdateData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // --- Event Handler Logic for Button Click ---

                // Get data from EditText fields
                String idString = editTextIdToUpdate.getText().toString().trim();
                String newName = editTextNewName.getText().toString().trim();
                String newAgeString = editTextNewAge.getText().toString().trim();

                // Basic validation
                if (idString.isEmpty() || newName.isEmpty() || newAgeString.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter ID, new name, and new age.", Toast.LENGTH_SHORT).show();
                    return; // Exit if fields are empty
                }

                int idToUpdate;
                int newAge;
                try {
                    idToUpdate = Integer.parseInt(idString);
                    newAge = Integer.parseInt(newAgeString);
                } catch (NumberFormatException e) {
                    Toast.makeText(MainActivity.this, "Please enter valid numbers for ID and Age.", Toast.LENGTH_SHORT).show();
                    return; // Exit if ID or Age is not a valid number
                }

                // Get a writable database instance
                SQLiteDatabase db = dbHelper.getWritableDatabase();

                // Create a new map of values for the update
                ContentValues values = new ContentValues();
                values.put(DatabaseHelper.COLUMN_NAME, newName);
                values.put(DatabaseHelper.COLUMN_AGE, newAge);

                // Define the WHERE clause and its arguments
                String selection = DatabaseHelper.COLUMN_ID + " = ?";
                String[] selectionArgs = { String.valueOf(idToUpdate) };

                // Update the row(s) matching the selection criteria
                // The update() method returns the number of rows affected.
                int count = db.update(
                        DatabaseHelper.TABLE_NAME, // The table to update
                        values,                    // The new column values
                        selection,                 // The WHERE clause
                        selectionArgs);            // The values for the WHERE clause

                // Check if the update was successful
                if (count > 0) {
                    Toast.makeText(MainActivity.this, "Data updated successfully for ID: " + idToUpdate, Toast.LENGTH_SHORT).show();
                    // Clear the input fields after successful update
                    editTextIdToUpdate.setText("");
                    editTextNewName.setText("");
                    editTextNewAge.setText("");
                } else {
                    Toast.makeText(MainActivity.this, "No data found with ID: " + idToUpdate + " or update failed.", Toast.LENGTH_SHORT).show();
                }

                // Close the database connection
                db.close();
            }
        });
    }

    // Close the database helper when the activity is destroyed
    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}
