package com.example.apl_2; // Replace with your actual package name

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.RatingBar; // Import RatingBar
import android.widget.TextView;  // Import TextView
import android.widget.Toast;   // Import Toast

public class MainActivity extends AppCompatActivity {

    // Declare UI elements
    private RatingBar ratingBar;
    private TextView textViewRatingValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content view to the activity_main.xml layout
        setContentView(R.layout.activity_main);

        // Initialize UI elements by finding them by their IDs from the layout
        ratingBar = findViewById(R.id.ratingBar);
        textViewRatingValue = findViewById(R.id.textViewRatingValue);

        // Set an OnRatingBarChangeListener to handle rating changes
        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                // This method is called when the rating is changed

                // Update the TextView to display the new rating value
                textViewRatingValue.setText("Rating: " + rating);

                // Optionally, show a Toast message
                if (fromUser) { // Only show Toast if the change was initiated by the user
                    Toast.makeText(MainActivity.this, "New Rating: " + rating, Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Set the initial text based on the default rating
        textViewRatingValue.setText("Rating: " + ratingBar.getRating());
    }
}
