package com.example.apl_2; // Replace with your actual package name

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat; // Import ContextCompat

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.pm.PackageManager; // Import PackageManager
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast; // Import Toast

public class MainActivity extends AppCompatActivity {

    // Declare the button
    private Button buttonShowNotification;

    // Define a unique ID for the notification channel
    private static final String CHANNEL_ID = "my_notification_channel";
    // Define a unique ID for the notification itself
    private static final int NOTIFICATION_ID = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content view to the activity_main.xml layout
        setContentView(R.layout.activity_main);

        // Initialize the button by finding it by its ID
        buttonShowNotification = findViewById(R.id.buttonShowNotification);

        // Create the NotificationChannel (required for Android 8.0 and higher)
        createNotificationChannel();

        // Set an OnClickListener for the button
        buttonShowNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // --- Event Handler Logic for Button Click ---

                // Build the notification
                NotificationCompat.Builder builder = new NotificationCompat.Builder(MainActivity.this, CHANNEL_ID)
                        .setSmallIcon(android.R.drawable.ic_dialog_info) // Set a small icon (required)
                        .setContentTitle("My First Notification") // Set the title
                        .setContentText("This is a simple notification example.") // Set the main text
                        .setPriority(NotificationCompat.PRIORITY_DEFAULT); // Set the priority (for older Android versions)

                // Get the NotificationManagerCompat instance
                NotificationManagerCompat notificationManager = NotificationManagerCompat.from(MainActivity.this);

                // Check if the app has the POST_NOTIFICATIONS permission (for Android 13+)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) { // TIRAMISU is API 33
                    if (ContextCompat.checkSelfPermission(MainActivity.this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                        // Permission is not granted, inform the user
                        Toast.makeText(MainActivity.this, "Notification permission not granted. Please enable it in app settings.", Toast.LENGTH_LONG).show();
                        // You would typically request the permission here in a real app
                        return; // Exit the onClick method
                    }
                }

                // Display the notification
                // The first parameter is a unique ID for this notification.
                try {
                    notificationManager.notify(NOTIFICATION_ID, builder.build());
                } catch (SecurityException e) {
                    // Handle the case where the permission is missing (e.g., on older Android versions
                    // where checkSelfPermission might not be sufficient or if the user revoked it)
                    Toast.makeText(MainActivity.this, "Failed to show notification. Permission denied.", Toast.LENGTH_LONG).show();
                    e.printStackTrace(); // Log the exception for debugging
                }
            }
        });
    }

    // Method to create the NotificationChannel
    private void createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "My Channel"; // User-visible name for the channel
            String description = "Channel for basic notifications"; // User-visible description
            int importance = NotificationManager.IMPORTANCE_DEFAULT; // Importance level

            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);

            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this.
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }
}
