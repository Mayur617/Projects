package com.example.apl_2; // Replace with your actual package name

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.CompoundButton; // Import CompoundButton
import android.widget.TextView;     // Import TextView
import android.widget.Toast;       // Import Toast
import android.widget.ToggleButton; // Import ToggleButton

public class MainActivity extends AppCompatActivity {

    // Declare UI elements
    private ToggleButton toggleButton;
    private TextView textViewState;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content view to the activity_main.xml layout
        setContentView(R.layout.activity_main);

        // Initialize UI elements by finding them by their IDs from the layout
        toggleButton = findViewById(R.id.toggleButton);
        textViewState = findViewById(R.id.textViewState);

        // Set the initial text based on the default state of the ToggleButton
        if (toggleButton.isChecked()) {
            textViewState.setText("Current State: ON");
        } else {
            textViewState.setText("Current State: OFF");
        }

        // Set an OnCheckedChangeListener to handle state changes
        toggleButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // This method is called when the checked state of the button has changed.
                // 'isChecked' is the new checked state of the button.

                if (isChecked) {
                    // If the button is now ON
                    textViewState.setText("Current State: ON");
                    Toast.makeText(MainActivity.this, "Toggle Button is ON", Toast.LENGTH_SHORT).show();
                } else {
                    // If the button is now OFF
                    textViewState.setText("Current State: OFF");
                    Toast.makeText(MainActivity.this, "Toggle Button is OFF", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
