package com.example.apl_2; // Replace with your actual package name

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    // Declare UI elements (optional for this simple example, but good practice)
    private ImageView imageViewBackground;
    private TextView textViewOverlay;
    private TextView textViewCorner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content view to the activity_main.xml layout
        setContentView(R.layout.activity_main);

        // Initialize UI elements by finding them by their IDs from the layout (optional)
        imageViewBackground = findViewById(R.id.imageViewBackground);
        textViewOverlay = findViewById(R.id.textViewOverlay);
        textViewCorner = findViewById(R.id.textViewCorner);

        // No specific logic needed for this basic FrameLayout example,
        // but you could add code here to interact with the views,
        // e.g., change text, change image, change visibility.
    }
}
