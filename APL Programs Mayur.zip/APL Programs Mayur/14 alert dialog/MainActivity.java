package com.example.apl_2; // Replace with your actual package name

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Declare the button
    private Button buttonShowDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content view to the activity_main.xml layout
        setContentView(R.layout.activity_main);

        // Initialize the button by finding it by its ID
        buttonShowDialog = findViewById(R.id.buttonShowDialog);

        // Set an OnClickListener for the button
        buttonShowDialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // --- Event Handler Logic for Button Click ---

                // Create an AlertDialog.Builder instance
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

                // Set the dialog's title and message
                builder.setTitle("Confirm Action");
                builder.setMessage("Are you sure you want to perform this action?");

                // Set the Positive button and its click listener
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // This code runs when the "Yes" button is clicked
                        Toast.makeText(MainActivity.this, "You clicked Yes", Toast.LENGTH_SHORT).show();
                        // You would typically perform the desired action here
                    }
                });

                // Set the Negative button and its click listener
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // This code runs when the "No" button is clicked
                        Toast.makeText(MainActivity.this, "You clicked No", Toast.LENGTH_SHORT).show();
                        // The dialog will be dismissed automatically
                    }
                });

                // Set the Neutral button and its click listener (optional)
                builder.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // This code runs when the "Cancel" button is clicked
                        Toast.makeText(MainActivity.this, "You clicked Cancel", Toast.LENGTH_SHORT).show();
                        // The dialog will be dismissed automatically
                    }
                });

                // Create and show the AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
    }
}
